package se.lublin.mumla;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.KeyEvent;


import java.util.HashSet;
import java.util.Set;

import se.lublin.mumla.service.MumlaService;

public class PTTReceiver extends BroadcastReceiver {

    private static final String TAG = "PTTReceiver";
    private static final String KEY_PREF = "key_bind";  // MUST match the key used in your preferences.xml

    private static final Set<Integer> activeKeys = new HashSet<>();


    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();

        Log.i("PTTReceiver", "Received action: " + action);

        if (MumlaService.instance == null) {
            Log.w("PTTReceiver", "PlumbleService not ready, ignoring intent: " + action);
            return; // gracefully ignore if app isn't initialized yet
        }

        if ("com.sonim.intent.action.PTT_KEY_DOWN".equals(action)) {
            MumlaService.instance.onTalkKeyDown();
        } else if ("com.sonim.intent.action.PTT_KEY_UP".equals(action)) {
            MumlaService.instance.onTalkKeyUp();
        }
    }



    private boolean isUserBoundKey(Context context, int keyCode) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        int configuredKey = prefs.getInt("key_bind", -1); // match your preference key!
        return keyCode == configuredKey;
    }

    private void sendPTTCommand(Context context, boolean pressed, String source) {
        Intent intent = new Intent(context, se.lublin.mumla.service.PTTForegroundService.class);
        intent.setAction(pressed
                ? "com.morlunk.mumbleclient.ACTION_PTT_DOWN"
                : "com.morlunk.mumbleclient.ACTION_PTT_UP");

        intent.putExtra("source", source); // tag the input type

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent);
        } else {
            context.startService(intent);
        }
    }
}
